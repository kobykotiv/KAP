#!/usr/bin/env python
# -*- coding: utf-8 -*- 
# I'm not responsible for anything. You should only use this to learn about ciphers.

from time import gmtime, strftime, sleep
import os
import random
from pandas import DataFrame
from itertools import cycle #You need itertools for this to work.
from functools import reduce #You also need functools for this to work.

s = .05 # Seconds until erase.
n = '''UTF-8''' # Base File Name
a = '''''' #Define the alphabet. We are using the entire utf-8 table. See line 92-97.

with open('u', 'r', encoding='utf-8') as f:
    data = f.read()
    a = str(data)
    f.close()

#This will create an encrypted file as a ONETIMEPAD. NOTE: This is intended only for single string messages.
def elog(text1,text2): 
        filename = "./_IN_logs/" + str(strftime("e-" + n + "-" + "%Y-%m-%d-%H-%M-%S", gmtime()) + ".log")
        print("writing to " + filename)
        with open(filename, 'w',encoding='utf-8') as f:
                f.write(text1)
                f.write("\n" + text2)
                f.close()

#This will create a super-duper spreadsheet! The First column is the 'key.' The Second column is 'code.'
def sprdenc(invt,filename):
        i = 0
        sfilename = "./_IN_logs/" + str(strftime("s-" + n + "-" + "%Y-%m-%d-%H-%M-%S", gmtime()) + ".xlsx")
        print("reading",filename)
        with open(filename,'r',encoding='utf-8') as f:
                data = f.readlines()
                pagenumber = len(data)
                f.close()
        print(pagenumber,'lines.')
        messagelist = list()
        keylist = list()
        cipherlist = list()
        for line in data:
                messagelist.append(line)
                key = str(rnd(len(line)))
                keylist.append(key)
                print(line)
                print(key)
                ciphertext = enc(invt,line,key) #For every line in the document... I want to run the line and its coorasponding key through the enc function.
                cipherlist.append(ciphertext)
                print(ciphertext) 
        #dictionary = dict(zip(messagelist,keylist))
        #print('\n',dictionary)
##        while i <= pagenumber:
##                print(dictionary)
##                i+=1
####        for items in dictionary:
##                print(dictionary.items())
##                ciphertext = enc(invt,dictionary[0],dictionary[1])
        print('MESSAGELIST\n',messagelist,'\n')
        print('KEYLIST\n',keylist,'\n')
        print('CIPHERLIST\n',cipherlist,'\n')

#This function will quickly show you the message and then it disapears from the Ternimal and from RAM.
def displayMessage(message): 
        cls()
        print(message)
        timetoclear = (s * len(message))
        if timetoclear >= 60:
                sleep(60)
                cls()
        else:
                sleep(timetoclear)
                cls()

def enc(invt,text,key): #([+1 is encrypt,-1 is decrypt],[The text you need ])
        pairs = zip(text, cycle(key))
        r = ''
        for pair in pairs:
                t = reduce(lambda x, y: a.index(x) + (invt * a.index(y)), pair)
                r += a[t % len(a)]
        return r

def rnd(length):
        return ''.join(random.SystemRandom().choice(a) for _ in range(length))

def cls():
        # os.system('cls' if os.name=='nt' else 'clear')
        print('...')

def TitleBar():
                cls()
                print(
"""
╔═╗┌┐┌┌─┐  ╔╦╗┬┌┬┐┌─┐  ╔═╗┌─┐┌┬┐
║ ║│││├─    ║ ││││├┤   ╠═╝├─┤ ││
╚═╝┘└┘└─┘   ╩ ┴┴ ┴└─┘  ╩  ┴ ┴─┴┘ utf-8 version.
""")

def getusrChoice():   
        # Let users know what they can do.
        TitleBar()
        print("[E]ncrypt string as a OneTimePad.")
        print("[D]ecrypt a string OneTimePad. (Requires key.)")
        print("Decrypt a [S]tring OneTimePadlog (Requires a '.log' file.)")
        print("Encrypt a [F]ile as OneTimePad. (Requires a file.)")
        # print("Decrypt a file [O]neTimePad as file. (Requires '.KOTP' file and '.filekey' file.)")
        print("[A]bout this Program.")
        print("[Q]uit.")
        return input("\nWhat would you like to do? " )

####################
### MAIN PROGRAM ###
####################

choice = ''
cls()
while choice != 'Q':    
        choice = getusrChoice()
        if choice == 'E':
                plaintext = input("Enter message: ")
                key = str(rnd(len(plaintext)))
                r = enc(+1,plaintext,key)
                elog(key,r)
                displayMessage(r)
        
        elif choice == 'D':
                ciphertext = input("Enter ciphertext: ")
                key = input("Enter key: ")
                r = enc(-1,ciphertext,key)
                displayMessage(r)

        elif choice == 'S':
                filepath = str(input("Path to file: "))
                with open(filepath, 'r',encoding='utf-8') as f:
                        data = f.readlines() #Reading The Lines of the OneTimePad.log file.
                        f.close()
                key = str(*data[0:1])
                message = str(*data[1:2])
                r = enc(-1,message,key)
                displayMessage(r)
                
        elif choice == 'F':
                filepath = input("Path to File: ")
                sprdenc(+1,filepath)
        # elif choice == 'O':
                # print("\nYou need to add this function later.")
        elif choice == 'A':
                print("\nThis is a OneTimePad cipher/solver tool. Developed by @KobyKotiv. Follow me on twitter.")
                sleep(1)
        elif choice == 'Q':
                print("Goodbye.")
        else:
                print("\nError! I did not understand that answer.")
