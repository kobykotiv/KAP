#!/usr/bin/env python
# -*- coding: utf-8 -*- 
# I'm not responsible for anything. You should only use this to learn about ciphers.

from base64 import b64encode
from time import gmtime, strftime, sleep
import os
from os import urandom
from itertools import cycle #You need itertools for this to work.
from functools import reduce #You also need functools for this to work.

s = 1 # Seconds until erase.
n = '''ASCII'''
a = '''!"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~'''

def elog(text1,text2):
	filename = "./_IN_logs/" + str(strftime("e-" + n + "-" + "%Y-%m-%d-%H-%M-%S", gmtime()) + ".log")
	print("writing to " + filename)
	with open(filename, 'w',encoding='utf-8') as f:
		f.write(text1)
		f.write("\n" + text2)
		f.close()

def enc(plaintext, key):
	pairs = zip(plaintext, cycle(key))
	r = ''

	for pair in pairs:
		t = reduce(lambda x, y: a.index(x) + a.index(y), pair)
		r += a[t % len(a)]
	
	elog(key,r)

def dnc(ciphertext, key):
	pairs = zip(ciphertext, cycle(key))
	r = ''
	
	for pair in pairs:
		t = reduce(lambda x, y: a.index(x) - a.index(y), pair)
		r += a[t % len(a)]
	print(r)

def rnd(length):
	rb = urandom(length)
	return b64encode(rb).decode('utf-8')

def cls():
	os.system('cls' if os.name=='nt' else 'clear')

def TitleBar():
		cls()
		print("  _____  __   _ _______ _______ _____ _______ _______  _____  _______ ______  ")
		print(" |     | | \  | |______    |      |   |  |  | |______ |_____| |_____| |     \ ")
		print(" |_____| |  \_| |______    |    __|__ |  |  | |______ |       |     | |_____/ ASCII \n")
		sleep(s)

def getusrChoice():   
	# Let users know what they can do.
	TitleBar()
	print("[E]ncrypt text as a OneTimePad.")
	print("[D]ecrypt a OneTimePad. (Requires key.)")
	print("[A]bout this Program.")
	print("[Q]uit.")
	return input("\nWhat would you like to do? " )

####################
### MAIN PROGRAM ###
####################
choice = ''
cls()
while choice != 'Q':	
	choice = getusrChoice()
	if choice == 'E':
		plaintext = input("Enter message: ")
		key = str(rnd(len(plaintext)))
		enc(plaintext, key)
	elif choice == 'D':
		ciphertext = input("Enter ciphertext: ")
		key = input("Enter key: ")
		dnc(ciphertext, key)
	elif choice == 'A':
		print("\nThis is a OneTimePad cipher/solver tool. Developed by @KobyKotiv. Follow me on twitter.")
	elif choice == 'Q':
		print("Goodbye.")
	else:
		print("Error! I did not understand that answer.")